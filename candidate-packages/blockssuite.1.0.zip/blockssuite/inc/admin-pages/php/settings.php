<?php
	// Exit if accessed directly.
	defined( 'ABSPATH' ) || exit;
	function settings_admin(){
		?>
			<div id="webkompanen-email-settings"></div>
		<?php
	}
?>